This is an update to deal with very large UBSAN output files caused by an int/double confusion in src/total.c

## Test environments
* Local Fedora 19 install, R 3.2.2 and devel (15/08/2015)
* win-builder (devel)

## R CMD check results
There were no ERRORs or WARNINGs.

There was 1 NOTE:

* checking CRAN incoming feasibility ... NOTE
Maintainer: ‘Simon Moulds <simon.moulds10@imperial.ac.uk>’

## Downstream dependencies
NA
