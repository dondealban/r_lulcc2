## Modified from 
## By me

## July 2016

## Master's Thesis: University of Leeds
## Model Development Case Study

## Load packages
## install.packages("lulcc", dependencies = TRUE)
library(lulcc)
library(RColorBrewer)  ## required for plotting
library(gsubfn)
library(rgdal)
library(sp)

setwd("E:/Working/Non_Forest/Reg7sub_2")

## Loads all data
lu_base <-raster("lu_base_2009.img")
lu_yr1 <- raster("lu_yr2_2011_2.img")
lu_yr2 <- raster("lu_yr4_2013_2.img")
ef_001 <- raster("ef_001.img")
ef_002 <- raster("ef_002.img")
ef_003 <- raster("ef_003.img")
ef_0004 <- raster("ef_004.img")
ef_2005 <- raster("ef_005.img")
ef_4006 <- raster("ef_006.img")
ef_007 <- raster("ef_007.img")
ef_008 <- raster("ef_008.img")
ef_2009 <-raster("ef_009.img")
ef_010 <- raster("ef_010.img")
ef_011 <- raster("ef_011.img")
mask <- raster("mask.img")


## Creates raster list of data
guy <- list(lu_base = lu_base, lu_yr1 = lu_yr1, lu_yr2 = lu_yr2, ef_001 = ef_001, ef_002 = ef_002, ef_003 = ef_003, ef_0004 = ef_0004, ef_2005 = ef_2005, ef_4006 = ef_4006, ef_007 = ef_007, ef_008 = ef_008,ef_2009=ef_2009,ef_010=ef_010,ef_011=ef_011)

## show data
head(guy)

## Creates an object from a list of raster objects
obs <- ObsLulcRasterStack(x=guy,
                          pattern="lu", 
                          categories=c(0,1,2,3), 
                          labels=c("Forest","Mining","Agriculture","Roads"), 
                          t=c(0,2,4))

## show object
#obs

## Plot Observed land use maps  
#p <- plot(obs,
         # between=list(x=0,y=0),
          #par.settings=list(axis.line=list(col="black"),
          #                  strip.background=list(col="lightgrey")),
         #par.strip.text=list(cex=0.6),
         # scales=list(cex=0.6),
         # col.regions=c("palegreen","midnightblue","darkgoldenrod1", "indianred1"),
          #colorkey=FALSE,
         # layout=c(3,1),
         # key=list(space="bottom",
                 #  cex=0.6,
                  # rectangles=list(col=c("palegreen","midnightblue", "darkgoldenrod1","indianred1"), size=3),
                  # text=list(labels=c("Agriculture","Forest","Mining","Roads"))))
##show plots
# p

## Cross tabulate change between Year 2009 and Year 2011
# crossTabulate(x=obs, times=c(0,4))

## Explanatory variables
ef <- ExpVarRasterList(x=guy, pattern="ef")
ef


## Fit Statistical Models 
## Random training and testing partitions from observed land use map 1-2009
## size = proportion of non-NA cells. 0.5 - equal sized partitions
part <- partition(x=obs[[1]], size=0.1, spatial=TRUE)

## Extract data frame containing variables for fitting predictive models
train.data <- getPredictiveModelInputData(obs=obs, ef=ef, cells=part[["train"]])

## get rid of the NAs in train.data

## Test 1 :Dist to rds, elevation, dis to riv, dist to minerals, slope. AIC = 5380  
#forms <- list(Mining ~ ef_001+ef_002+ef_003+ef_007+ef_008,
#              Forest ~ 1, 
#              Agriculture ~ 1,
#              Roads ~ 1)

##Test 2: Dist to rds, dis to riv, dist to minerals, slope. AIC = 5653 
#forms <- list(Mining ~ ef_001+ef_003+ef_007+ef_008,
#              Forest ~ 1, 
#              Agriculture ~ ef_001+ef_008,
#              Roads ~ 1)

##Test 3: Dist to riv, rd_base, rd_yr1, rd_yr2, dist to minerals, slope. AIC = 8
#forms <- list(Mining ~ ef_003+ef_0004+ef_1005+ef_2006+ef_007+ef_008,
#              Forest ~ 1, 
#              Agriculture ~ ef_011+ef_008,
#              Roads ~ 1)

##Test 4:No slope. AIC = 6
#forms <- list(Mining ~ ef_003+ef_0004+ef_1005+ef_2009+ef_007,
#              Forest ~ ef_003+ef_004, 
#              Agriculture ~ ef_001+ef_008,
#              Roads ~ 1)

## Test 5: AIC = 4
#forms <- list(Mining ~ ef_0004+ef_2005+ef_4006+ef_007,
#              Forest ~ 1, 
#              Agriculture ~ 1,
#              Roads ~ 1)

## Test 6: Final 
forms <- list(Mining ~ ef_002+ef_003+ef_0004+ef_2005+ef_4006+ef_007+ef_008+ef_010+ef_011,
              Forest ~ ef_001+ef_002+ef_003+ef_0004+ef_2005+ef_4006+ef_007+ef_008+ef_010+ef_011, 
              Agriculture ~1,
              Roads ~ 1)

## Run predictive models on training partition 
glm.models <- glmModels(formula=forms, family=binomial, data=train.data, obs=obs)
# g.m <- glm(Mining ~ ef_001+ef_003+ef_007+ef_008, family = "binomial", data = train.data, model = F)
# g.o <- new("PredictiveModelList", models = g.m, categories = 1, labels = "Mining")

# rpart.models <- rpartModels(formula=forms, data=train.data, obs=obs)
# rf.models <- randomForestModels(formula=forms, data=train.data, obs=obs)

## Check glm model results
glm.models


## Create suitability maps. Does not work. 
#all.data <- as.data.frame(x=ef, cells=part[['all']])
#probmaps <- predict(object=glm.models, newdata=all.data, data.frame=TRUE)
#points <- rasterToPoints(obs[[1]], spatial=TRUE)
#probmaps <- SpatialPointsDataFrame(points, probmaps)
#index <- !is.na(probmaps$Mining)
#pm <- probmaps[index, "Mining"]
#plot(probmaps, pch = 1, cex = pm$Mining)
#hist(pm$Mining)


## Rasterise data to be plotted. Computer intensive does not work!
#r <- rasterize(x=probmaps, y=obs[[1]], field=names(probmaps))


## Plot suitability maps based on random training partition model fit 
#p <- rasterVis::levelplot(r,
#                          layout=c(4,1),
#                          margin=FALSE,
#                          par.strip.text=list(cex=0.6),
#                          par.settings=list(axis.line=list(col="black"),
#                                            strip.background=list(col="lightgrey")),
#                          between=list(x=0,y=0),
#                          col.regions=colorRampPalette(brewer.pal(9, "YlGnBu")),
#                          at=seq(0,1,length=100),
#                          scales=list(cex=0.6),
#                          colorkey=list(space="bottom",labels=list(cex=0.6),width=0.5))
## show plot
#p

## trellis.device(device="pdf", width=4.72, height=3, file="f05_roc.pdf", family="Courier")
## print(p)
## dev.off()




## Model Testing Based on One Land Use Category
## Test ability of models to predict location of mining gain 2009 -> 2011
##extracts data frame for fitting models

part <- rasterToPoints(obs[[1]], fun=function(x) x !=0, spatial=TRUE) # x != (c1,2)
test.data <- getPredictiveModelInputData(obs=obs, ef=ef, cells=part, t=2)

## Create prediction list object. Performance list to keep track of criteria from diff models.
glm.pred <- PredictionList(models=glm.models[[2]], newdata=test.data)
glm.perf <- PerformanceList(pred=glm.pred, measure="rch")


## ROC curve: model fit of 2009 to predict mining in 2011. 
p <- plot(list(glm=glm.perf),
          aspect="iso",
          xlab=list(label="False Alarms/(False Alarms + Correct Rejections)", cex=0.6),
          ylab=list(label="Hits/(Hits + Misses)", cex=0.6),
          scales=list(x=list(tck=0.6), y=list(tck=0.6), cex=0.6),
          key.args=list(cex=0.6, size=2.5),
          par.strip.text=list(cex=0.6),
          par.settings=list(strip.background=list(col="lightgrey")))
p

## trellis.device(device="pdf", width=3.27, height=3.27, file="f06_builtgain.pdf", family="Courier")
## print(p)
## dev.off()




## Criteria for Clue-S

## obtain demand scenario and get change direction for first time step
dmd <- approxExtrapDemand(obs=obs, tout=0:2)
dmd2 <- approxExtrapDemand(obs=obs, tout=0:4)
dmd3 <- approxExtrapDemand(obs=obs, tout=0:15)

## plot demand between year 0 and 2 (2009 and 2011)
plot(x = 1:3, y = dmd[,2], ylab = "no of cells", xlab = "Time point")
lines(x = 1:3, y = dmd[,2], col = "red")
title("Mining")

## plot demand between year 0 and 2 (2009 and 2024)
plot(x = 1:16, y = dmd[,2], ylab = "no of cells", xlab = "Time point")
lines(x = 1:16, y = dmd[,2], col = "red")
title("Mining")

## plot demand scenario (figure not shown in paper)
##matplot(dmd, type="l", ylab="Demand (no. of cells)", xlab="Time point", lty=1, col=c("Green","Red","Blue"))
##legend("topleft", legend=obs@labels, col=c("Green","Red","Blue"), lty=1)

## neighbourhood values
w <- matrix(data=1, nrow=3, ncol=3)  
nb <- NeighbRasterStack(x=obs[[1]], weights=w, categories=c(0,1))


# Testing neighbourhood fucntions
## update for 2011
#nb2 <- NeighbRasterStack(x=obs[[2]],
#                         neighb=nb)

# update for 2013
#nb3 <- NeighbRasterStack(x=obs[[3]],
#                         neighb=nb2)

# input into allow method
#nb.allow <- allowNeighb(neighb=nb,
#                        x=obs[[1]],
#                        categories=obs@categories,
#                        rules=1)

#nb.allow2 <- allowNeighb(neighb=nb2,
#                         x=obs[[2]],
#                         categories=obs@categories,
#                         rules=1)

#nb.allow3 <- allowNeighb(neighb=nb3,
#                         x=obs[[3]],
#                         categories=obs@categories,
#                         rules=1)


## Part 2. create CLUE-S model object

# Testing transition rules 
#clues.rules <- matrix(data=1,1,1,1,
#                      0,1,0,1,
#                      0,1,1,0,
#                      1,1,0,1, nrow=4, ncol=4, byrow=TRUE) 



clues.rules <- matrix(data=1,nrow=4, ncol=4, byrow=TRUE) 

clues.parms <- list(jitter.f=0.0002,
                    scale.f=0.000001,
                    max.iter=1000,
                    max.diff=50, 
                    ave.diff=50) 

clues.model <- CluesModel(obs=obs,
                          ef=ef,
                          models=glm.models,
                          time=0:4,
                          demand=dmd3,
                          neighb=nb,
                          elas=c(0.1,0.3,0.2,0.2),
                          rules=clues.rules,
                          params=clues.parms)


## perform allocation
clues.model <- allocate(clues.model)


 ## Validation
## CLUE-S
clues.tabs <- ThreeMapComparison(x=clues.model,
                                 factors=2^(1:8),
                                 timestep=2)

## plot three dimensional tables in different ways (figures not shown in paper)
plot(clues.tabs)
plot(clues.tabs, category=1, factors=2^(1:8)[c(1,3,5,7)])


## calculate agreement budget and plot

## CLUE-S
clues.agr <- AgreementBudget(x=clues.tabs)
p1 <- plot(clues.agr,
           from=0,
           to=1,
           par.strip.text=list(cex=0.6),
           par.settings=list(strip.background=list(col="lightgrey")),
           xlab=list(cex=0.6),
           ylab=list(cex=0.6),
           ylim=c(0,0.08),
           scales=list(y=list(at=c(seq(from=0,to=0.02,by=0.01)), cex=0.6, tck=0.6), x=list(cex=0.6, tck=0.6)),
           key=list(cex=0.6))
p1


## trellis.device(device="pdf", width=4.72, height=5.72, file="/home/simon/projects/lulccR_paper/RevisedDraft/f07_agreement.pdf")
## print(agr.p)
## dev.off()

## calculate Figure of Merit and plot

## CLUE-S
clues.fom <- FigureOfMerit(x=clues.tabs)
p1 <- plot(clues.fom,
           from=0,
           to=1,
           par.strip.text=list(cex=0.6),
           par.settings=list(strip.background=list(col="lightgrey")),
           xlab=list(cex=0.6),
           ylab=list(cex=0.6),
           ylim=c(0,1),
           scales=list(y=list(at=(seq(from=0,to=1,by=0.2)), cex=0.6), x=list(cex=0.6)),
           key=NULL)
p1



